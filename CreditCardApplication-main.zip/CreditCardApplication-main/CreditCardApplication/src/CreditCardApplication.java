public class CreditCardApplication
{
    public static void main(String[] args)
    {
        Login login = new Login();
    }
}
